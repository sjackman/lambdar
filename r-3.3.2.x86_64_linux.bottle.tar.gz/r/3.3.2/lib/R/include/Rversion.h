/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 197378
#define R_NICK "Sincere Pumpkin Patch"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "3"
#define R_MINOR  "3.2"
#define R_STATUS ""
#define R_YEAR   "2016"
#define R_MONTH  "10"
#define R_DAY    "31"
#define R_SVN_REVISION 71607
#define R_FILEVERSION    3,32,71607,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
